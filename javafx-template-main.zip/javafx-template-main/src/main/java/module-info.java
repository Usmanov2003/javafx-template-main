module com.example.app {
    requires javafx.controls;
    requires org.slf4j;

    exports com.example.app;
}